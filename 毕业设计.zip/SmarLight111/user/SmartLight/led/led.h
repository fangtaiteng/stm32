#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h"
void LED_GPIO_Config();
void LED_GPIO_Close_Config();
void auto_switch();
void LED_open();
void LED_close();


#endif