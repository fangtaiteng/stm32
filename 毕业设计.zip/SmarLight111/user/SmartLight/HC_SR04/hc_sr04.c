//#include "hc_sr04.h"
//#include "delay.h"
//#include "timer.h"
//#include "led.h"
//float distance;

//void hc_sr04_Init()
//{
//	GPIO_InitTypeDef  GPIO_InitSture;
//	EXTI_InitTypeDef  EXTI_InitSture;
//	NVIC_InitTypeDef  NVIC_InitSture;
//	//如果外部中断的话则一定使能AFIO复用功能
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOA,ENABLE);
//	//配置IO端口
//	GPIO_InitSture.GPIO_Mode=GPIO_Mode_Out_PP;   				//推挽输出模式
//	GPIO_InitSture.GPIO_Pin=GPIO_Pin_1;                //将PB1与trig端相连
//	GPIO_InitSture.GPIO_Speed=GPIO_Speed_50MHz;  
//	GPIO_Init(GPIOB,&GPIO_InitSture);
//	
//	GPIO_InitSture.GPIO_Mode=GPIO_Mode_IPD;      				//下拉输入模式
//	GPIO_InitSture.GPIO_Pin=GPIO_Pin_6;                //将PA6于Echo相连
//	GPIO_InitSture.GPIO_Speed=GPIO_Speed_50MHz;  
//	GPIO_Init(GPIOA,&GPIO_InitSture);
//	
//	//中断和6端口映射一起
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource6);
//	
//	//外部中断配置
//	EXTI_InitSture.EXTI_Line=EXTI_Line6;
//	EXTI_InitSture.EXTI_LineCmd=ENABLE;
//	EXTI_InitSture.EXTI_Mode=EXTI_Mode_Interrupt;
//	EXTI_InitSture.EXTI_Trigger=EXTI_Trigger_Rising;
//	EXTI_Init(&EXTI_InitSture);
//	
//	
//	//中断优先级管理
//	NVIC_InitSture.NVIC_IRQChannel=EXTI9_5_IRQn;
//	NVIC_InitSture.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_InitSture.NVIC_IRQChannelPreemptionPriority=0;
//	NVIC_InitSture.NVIC_IRQChannelSubPriority=1;
//	NVIC_Init(&NVIC_InitSture);
//}

//void EXTI9_5_IRQHandler(void)
//{
//	static int times =0;
//	Delay_us(10);
//	if(EXTI_GetITStatus(EXTI_Line6)!=RESET)
//	{
//		TIM_SetCounter(TIM3,0);
//		TIM_Cmd(TIM3,ENABLE);															//定时器开始计时
//		LED_open();																				//触发中断亮灯测试
//		while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6));  //等待低电平
//		TIM_Cmd(TIM3,DISABLE);														//定时器停止计时
//		LED_close();																			//等到了低电平灭灯
//		distance+=(TIM_GetCounter(TIM3))/1000000*340/2 *100;//此处单位转换为cm
//		
//		
//		EXTI_ClearITPendingBit(EXTI_Line6);
//	}
//}

////取得5次测量的平均值



////发送20us的脉冲触发信号
//void HC_SR04_start()
//{
//	GPIO_SetBits(GPIOB,GPIO_Pin_1);
//	Delay_us(20);
//	GPIO_ResetBits(GPIOB,GPIO_Pin_1);
//	Delay_ms(1000);
//}


//void TIM3_Config()
//{
//  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
//	NVIC_InitTypeDef NVIC_InitStructure;

//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //时钟使能APB1
//	//定时器中断一次的时间是1ms
//	TIM_TimeBaseStructure.TIM_Period = 49999; //设置在下一个更新事件装入活动的自动重装载寄存器周期的值	 计数到5000为50ms
//	TIM_TimeBaseStructure.TIM_Prescaler = 71; //设置用来作为TIMx时钟频率除数的预分频值  10Khz的计数频率  计数一次1us
//	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //设置时钟分割:TDTS = Tck_tim
//	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM向上计数模式
//	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //根据TIM_TimeBaseInitStruct中指定的参数初始化TIMx的时间基数单位
// 
//	TIM_ITConfig(  //使能或者失能指定的TIM中断
//		TIM3, //TIM3
//		TIM_IT_Update ,//更新中断
//		ENABLE  //使能
//		);
//	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  //TIM3中断
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //先占优先级0级
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  //从优先级0级
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
//	NVIC_Init(&NVIC_InitStructure);  //根据NVIC_InitStruct中指定的参数初始化外设NVIC寄存器

//	//TIM_Cmd(TIM3, ENABLE);  //使能TIMx外设 定时器使能
//							 
//}

//void TIM3_IRQHandler()   //TIM3中断
//{ 
//	//static int flag = 0;
/////static int time = 0;
//	if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) //检查指定的TIM中断发生与否:TIM 中断源 
//		{
//			//time++;
//			//if(time == 1000)
//			//{
//			//	time = 0;
//				//switch(flag)
//				//{
//					//case 0:
//					//	LED_open(); //定义的LED灯
//					//	flag = 1;
//				//	break;
//				//	case 1:
//					//	LED_close(); //定义的LED灯
//					//	flag = 0;
//					//break;
//				//}
//			}
//			
//			TIM_ClearITPendingBit(TIM3, TIM_IT_Update);  //清除TIMx的中断待处理位:TIM 中断源 
//		//}
//}
