#ifndef __HC_SR04_H
#define __HC_SR04_H
 
#include "stm32f10x.h"
 
void TIM3_Config();
void TIM3_IRQHandler();
void HC_SR04_start();
void EXTI9_5_IRQHandler(void);
void hc_sr04_Init();
float getDistance();
 
 
#endif /* __HC_SR04_H*/