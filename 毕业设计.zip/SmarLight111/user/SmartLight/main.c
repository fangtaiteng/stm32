#include "stm32f10x.h"
#include "mode_key.h"
#include "hand_key.h"
#include "Light_Sensor.h"
#include "hc_sr501.h"
#include "delay.h"
#include "led.h"
#include "pwm.h"

int main()
{	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);			//中断优先级分组设置为组2
	PWM_key0_exti_init();					//亮度调节按钮1初始化
	PWM_key1_exti_init();					//亮度调节按钮2初始化
  hand_key_gpio_init()	;				//手动模式按键GPIO初始化
	hand_key_exti_init();				//手动模式按键中断初始化
	EXTI2_IRQHandler();					//手动模式按键中断处理函数
  mode_key_exti_init();				//切换功能按键中断初始化
	EXTI1_IRQHandler();					//切换功能按键中断处理函数
	EXTI9_5_IRQHandler();				//调节亮度中断函数初始化
	EXTI0_IRQHandler();						//调节亮度中断函数初始化
	Light_Sensor_GPIO_Config();		//光敏传感器初始化
	Light_Sensor_open();					//默认开启自动模式即默认开启光敏传感器
	
	while(1)
	{
		HC_SR501_switch();			//调用人体传感器开关功能函数	
		auto_switch();					//调用自动开关灯功能函数	
		
	}
}
