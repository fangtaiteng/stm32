#include "hc_sr501.h"
#include "Light_Sensor.h"
#include "led.h"
void HC_SR501_Config()
{
	GPIO_InitTypeDef GPIO_InitStructure; //定义初始化结构体
	//信号输入端口初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE); //初始化GPIO的时钟
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15; //引脚位
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//输出速度
	GPIO_Init(GPIOC,&GPIO_InitStructure);//调用库函数的GPIO初始化函数
	GPIO_ResetBits(GPIOC,GPIO_Pin_15);
}



void HC_SR501_Close_Config()
{
	GPIO_InitTypeDef GPIO_InitStructure; //定义初始化结构体
	//信号输入端口初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,DISABLE); //初始化GPIO的时钟
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_15; //引脚位
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//输出速度
	GPIO_Init(GPIOC,&GPIO_InitStructure);//调用库函数的GPIO初始化函数
	GPIO_ResetBits(GPIOC,GPIO_Pin_15);

}


void HC_SR501_switch()		//当周围环境变暗时才会开启人体红外传感器
{
	switch(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3))
	{
		case 1:								//环境变暗，开启人体传感器
			 HC_SR501_Config();
		break;
		case 0:
			HC_SR501_Close_Config();
		break;
	}
}
