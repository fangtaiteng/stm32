#ifndef __HC_SR501_H
#define __HC_SR501_H
#include "stm32f10x.h"

void HC_SR501_Config();
void HC_SR501_switch();
void EXTI15_10_IRQHandler(void);
#endif