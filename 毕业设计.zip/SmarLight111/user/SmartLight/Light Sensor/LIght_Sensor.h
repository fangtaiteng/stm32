#ifndef __LIGHT_SENSOR_H
#define __LIGHT_SENSOR_H
#include "stm32f10x.h"
void Light_Sensor_GPIO_Config();
void Light_Sensor_open();
void Light_Sensor_close();


#endif