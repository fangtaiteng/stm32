#include "Light_Sensor.h"
#include "hc_sr501.h"
#include "delay.h"
void Light_Sensor_GPIO_Config()
{
	GPIO_InitTypeDef GPIO_InitStructure; //定义初始化结构体
	//信号输入端口初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE); //初始化GPIO的时钟
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3; //引脚位
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//输出速度
	GPIO_Init(GPIOA,&GPIO_InitStructure);//调用库函数的GPIO初始化函数
	//供电端口初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE); //初始化GPIO的时钟
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_5; //引脚位
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//输出速度
	GPIO_Init(GPIOB,&GPIO_InitStructure);//调用库函数的GPIO初始化函数
	GPIO_SetBits(GPIOB,GPIO_Pin_5);
}

void Light_Sensor_open()
{
	GPIO_SetBits(GPIOB,GPIO_Pin_5);
	
}

void Light_Sensor_close()
{
	GPIO_ResetBits(GPIOB,GPIO_Pin_5);
}