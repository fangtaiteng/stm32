#include "mode_key.h"
#include "hand_key.h"
#include "Light_Sensor.h"
#include "delay.h"
#include "led.h"
//切换模式按键中断初始化
void mode_key_exti_init(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;		
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO,ENABLE);	//开启GPIOA端口时钟和AFIO复用时钟
	//配置中断使用的GPIO：PA_1
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;			//下拉输入
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//PA_1连接到外部中断管理器EXITLine2
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource1);
	//配置外部中断
	EXTI_InitStructure.EXTI_Line = EXTI_Line1;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;				
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;		//上升沿触发
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	//配置NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

//模式切换按键中断处理函数
void EXTI1_IRQHandler(void)
{
	static int modeflag = 0;	//模式状态标志
	if(EXTI_GetITStatus(EXTI_Line1)!=RESET)
	{
		LED_GPIO_Close_Config();		//关闭LED的GPIO端口
		switch(modeflag)
		{
			case 0:
				GPIO_SetBits(GPIOB,GPIO_Pin_13);		//为0时，开启手动模式按钮
				Light_Sensor_close();									//关闭光敏传感器供电
				modeflag = 1;														//修改状态值
			break;
			case 1:
				GPIO_ResetBits(GPIOB,GPIO_Pin_13);		//为1时，关闭手动按钮供电
				Light_Sensor_open();									//开启光敏传感器供电
				modeflag = 0;
			break;
		}
		Delay_ms(200);
		EXTI_ClearITPendingBit(EXTI_Line1);				//清除中断
		
	}
}

