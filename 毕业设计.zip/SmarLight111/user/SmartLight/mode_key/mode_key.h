#ifndef __MODE_KEY_H
#define __MODE_KEY_H
#include "stm32f10x.h"
void mode_key_exti_init(void);
void EXTI1_IRQHandler(void);
#endif