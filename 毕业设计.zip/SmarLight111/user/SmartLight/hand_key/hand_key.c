#include "hand_key.h"
#include "led.h"
#include "delay.h"
//给手动按键通电的接口初始化
void hand_key_gpio_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE); //初始化GPIO的时钟
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	//GPIO_SetBits(GPIOB,GPIO_Pin_13);
}

//手动模式按键中断初始化
void hand_key_exti_init(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;		
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO,ENABLE);	//开启GPIOA端口时钟和AFIO复用时钟
	//配置中断使用的GPIO：PA_2
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;			//下拉输入
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//PA_2连接到外部中断管理器EXITLine2
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource2);
	//配置外部中断
	EXTI_InitStructure.EXTI_Line = EXTI_Line2;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;				
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;		//上升沿触发
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	//配置NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

//手动按键中断处理函数
void EXTI2_IRQHandler(void)
{
	static int ledflag = 0;	//led状态标志
	if(EXTI_GetITStatus(EXTI_Line2) !=RESET)
	{
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9))
		{
			ledflag = 1;	//判断是否当切换到手动模式时灯的状态，根据状态修改状态标志。
		}
		switch(ledflag)
		{
			case 0:
				LED_open();														//开灯
				ledflag = 1;													//修改状态值
			break;
			case 1:
				LED_close();													//关灯
				ledflag = 0;
			break;
		}
		Delay_ms(200);
		EXTI_ClearITPendingBit(EXTI_Line2);				//清除中断
	}
}

