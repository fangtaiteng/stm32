#ifndef __HAND_KEY_H
#define __HAND_KEY_H
#include "stm32f10x.h"
void hand_key_gpio_init(void);
void hand_key_exti_init(void);
void EXTI2_IRQHandler(void);



#endif