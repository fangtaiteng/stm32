#ifndef __PWM_H__
#define __PWM_H__

#include "stm32f10x.h"



void PWM_key0_exti_init(void);
void PWM_key1_exti_init(void);
void EXTI0_IRQHandler(void);
void EXTI9_5_IRQHandler(void);

#endif
